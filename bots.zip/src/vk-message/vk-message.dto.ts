export class VkMessageDto {
  message: string;
  attachment?: string[];
  user_ids: string;
}
